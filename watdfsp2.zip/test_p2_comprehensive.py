#!/usr/bin/env python3
"""
WatDFS Project 2 – Comprehensive Integration Test
===================================================
Stages:
  1. Unopened API Sandwich   (Section 7.1.6)
  2. Mode-Based Freshness    (Section 7.1.6 Optimization)
  3. SWMR & Transfer Atomicity (Section 7.1.2 / 7.2.4)
  4. Fsync & Release          (Section 7.1.5 / 7.2.5 / 7.2.6)

Uses low-level os calls wherever possible.
Prints PASS/FAIL per stage and exits with a summary.
"""

import os
import re
import sys
import time
import errno
import signal
import subprocess
from pathlib import Path

# ──────────────────────────────────────────────────────────────────────────────
#  Helper utilities (mirrors itest.py / existing tests)
# ──────────────────────────────────────────────────────────────────────────────

CACHE_INTERVAL = 5  # seconds – must match CACHE_INTERVAL_SEC env var

def run(cmd, **kwargs):
    return subprocess.run(cmd, text=True, capture_output=True, **kwargs)

def is_mounted(mount_dir: Path) -> bool:
    cp = subprocess.run(["mountpoint", "-q", str(mount_dir)])
    return cp.returncode == 0

def fusermount_u(mount_dir: Path):
    subprocess.run(
        ["fusermount", "-u", str(mount_dir)],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )

def terminate_proc(p):
    if p is None:
        return
    if p.poll() is not None:
        return
    try:
        p.terminate()
        p.wait(timeout=2)
    except Exception:
        try:
            p.kill()
        except Exception:
            pass

def wait_for_mount(mount_dir: Path, timeout_s: float = 5.0) -> bool:
    t0 = time.time()
    while time.time() - t0 < timeout_s:
        if is_mounted(mount_dir):
            return True
        time.sleep(0.05)
    return False

def wait_for_server_env(server_proc, timeout_s: float = 5.0):
    addr = port = None
    buf = ""
    t0 = time.time()
    while time.time() - t0 < timeout_s:
        line = server_proc.stdout.readline() if server_proc.stdout else ""
        if line:
            buf += line
            m1 = re.search(r"export\s+SERVER_ADDRESS\s*=\s*([^\s]+)", buf)
            m2 = re.search(r"export\s+SERVER_PORT\s*=\s*([0-9]+)", buf)
            if m1:
                addr = m1.group(1).strip()
            if m2:
                port = m2.group(1).strip()
            if addr and port:
                return addr, port, buf
        else:
            time.sleep(0.05)
    return addr, port, buf

# ──────────────────────────────────────────────────────────────────────────────
#  Bookkeeping
# ──────────────────────────────────────────────────────────────────────────────

results = []  # list of (name, passed:bool)

def report(name, passed, detail=""):
    tag = "PASS ✅" if passed else "FAIL ❌"
    suffix = f"  ({detail})" if detail else ""
    print(f"    [{tag}] {name}{suffix}")
    results.append((name, passed))

def print_summary():
    total = len(results)
    passed = sum(1 for _, p in results if p)
    failed = total - passed
    print("\n" + "=" * 60)
    print(f"  SUMMARY: {passed}/{total} passed, {failed} failed")
    if failed:
        print("  FAILED tests:")
        for name, p in results:
            if not p:
                print(f"    - {name}")
    print("=" * 60)
    return 0 if failed == 0 else 1

# ──────────────────────────────────────────────────────────────────────────────
#  Setup / teardown
# ──────────────────────────────────────────────────────────────────────────────

def setup():
    """Build, start server+client, return (server_proc, client_proc, dirs)."""
    here = Path(".").resolve()

    # Build
    print("[setup] Building with `make clean all`...")
    build = run(["make", "clean", "all"])
    if build.returncode != 0:
        print("BUILD FAILED ❌")
        print(build.stdout)
        print(build.stderr)
        sys.exit(1)
    print("[setup] Build OK ✅")

    server_bin = here / "watdfs_server"
    client_bin = here / "watdfs_client"

    base = Path(f"/tmp/{os.environ.get('USER', 'user')}/watdfs_p2_test")
    server_dir = base / "server"
    cache_dir  = base / "cache"
    mount_dir  = base / "mount"
    logs_dir   = base / "logs"

    for d in [server_dir, cache_dir, mount_dir, logs_dir]:
        if d.exists() and d == mount_dir:
            fusermount_u(d)
        run(["rm", "-rf", str(d)])
        d.mkdir(parents=True, exist_ok=True)

    # Start server
    print("[setup] Starting server...")
    server_err = (logs_dir / "server.err").open("w")
    server_proc = subprocess.Popen(
        [str(server_bin), str(server_dir)],
        stdout=subprocess.PIPE,
        stderr=server_err,
        text=True,
        bufsize=1,
    )

    addr, port, captured = wait_for_server_env(server_proc)
    if not addr:
        addr = os.environ.get("SERVER_ADDRESS", "localhost")
    if not port:
        port = os.environ.get("SERVER_PORT")
    if not port:
        print("❌ Could not determine SERVER_PORT")
        print("Server output so far:", captured)
        terminate_proc(server_proc)
        sys.exit(2)

    print(f"[setup] SERVER_ADDRESS={addr}  SERVER_PORT={port}")

    # Start client
    print("[setup] Starting client (FUSE mount)...")
    env = os.environ.copy()
    env["SERVER_ADDRESS"] = addr
    env["SERVER_PORT"] = str(port)
    env["CACHE_INTERVAL_SEC"] = str(CACHE_INTERVAL)

    client_out = (logs_dir / "client.out").open("w")
    client_err = (logs_dir / "client.err").open("w")

    client_proc = subprocess.Popen(
        [str(client_bin), "-s", "-f", "-o", "direct_io",
         str(cache_dir), str(mount_dir)],
        stdout=client_out,
        stderr=client_err,
        env=env,
        text=True,
        bufsize=1,
    )

    if not wait_for_mount(mount_dir):
        print("❌ Mount failed")
        terminate_proc(client_proc)
        terminate_proc(server_proc)
        sys.exit(3)

    print("[setup] Mount active ✅\n")
    dirs = {
        "server": server_dir,
        "cache": cache_dir,
        "mount": mount_dir,
        "logs": logs_dir,
    }
    return server_proc, client_proc, dirs

def teardown(server_proc, client_proc, mount_dir):
    print("\n[teardown] Cleaning up...")
    fusermount_u(mount_dir)
    time.sleep(0.3)
    terminate_proc(client_proc)
    terminate_proc(server_proc)
    print("[teardown] Done.")

# ──────────────────────────────────────────────────────────────────────────────
#  Stage 1: Unopened API Sandwich (Section 7.1.6)
# ──────────────────────────────────────────────────────────────────────────────

def stage1(dirs):
    print("=" * 60)
    print("  STAGE 1: Unopened API Sandwich (Section 7.1.6)")
    print("=" * 60)

    server_dir = dirs["server"]
    cache_dir  = dirs["cache"]
    mount_dir  = dirs["mount"]

    # ── 1a. Mknod ─────────────────────────────────────────────────────────
    name = "1a-mknod"
    try:
        p = str(mount_dir / "s1_mknod.txt")
        # os.mknod creates a regular file node (S_IFREG | mode)
        os.mknod(p, 0o100644)

        time.sleep(0.5)
        on_server = (server_dir / "s1_mknod.txt").exists()
        on_cache  = (cache_dir  / "s1_mknod.txt").exists()
        report(name, on_server and on_cache,
               f"server={on_server}, cache={on_cache}")
    except Exception as e:
        report(name, False, str(e))

    # ── 1b. Truncate on unopened file ─────────────────────────────────────
    name = "1b-truncate-unopened"
    try:
        # Create a file with some content first.
        p_mount = str(mount_dir / "s1_trunc.txt")
        fd = os.open(p_mount, os.O_CREAT | os.O_RDWR)
        os.write(fd, b"A" * 100)
        os.close(fd)

        # Give release time to upload.
        time.sleep(0.5)

        # Now truncate while file is NOT open.
        os.truncate(p_mount, 42)

        # Verify server-side size.
        time.sleep(0.5)
        srv_size = os.stat(str(server_dir / "s1_trunc.txt")).st_size
        report(name, srv_size == 42, f"server size={srv_size}, expected=42")
    except Exception as e:
        report(name, False, str(e))

    # ── 1c. Utimensat on unopened file ────────────────────────────────────
    #   The not-open path does open(WR)->utimensat->release.  Release
    #   uploads (since writable), and upload_file aligns mtime with the
    #   server's post-write mtime.  So the target_time we set is NOT
    #   preserved on the server.  We only check the call succeeds and
    #   the server mtime is recent (within last 10 s).
    name = "1c-utimensat-unopened"
    try:
        p_mount = str(mount_dir / "s1_trunc.txt")  # reuse existing file
        target_time = 1_000_000_000  # epoch 2001-09-09
        os.utime(p_mount, (target_time, target_time))

        time.sleep(0.5)
        srv_mtime = int(os.stat(str(server_dir / "s1_trunc.txt")).st_mtime)
        now = int(time.time())
        # After upload, server mtime should be recent (the upload wrote content).
        report(name, abs(now - srv_mtime) <= 10,
               f"server mtime={srv_mtime}, now={now} (delta={abs(now - srv_mtime)}s)")
    except Exception as e:
        report(name, False, str(e))

    # ── 1c2. Utimensat on *open* file (local-only, timestamps preserved) ─
    name = "1c2-utimensat-open"
    try:
        fname = "s1_utime_open.txt"
        p_mount = str(mount_dir / fname)
        fd = os.open(p_mount, os.O_CREAT | os.O_RDWR)
        os.write(fd, b"utime-open-test")

        target_time = 1_000_000_000
        os.utime(p_mount, (target_time, target_time))

        cache_mtime = int(os.stat(str(cache_dir / fname)).st_mtime)
        os.close(fd)

        report(name, abs(cache_mtime - target_time) <= 1,
               f"cache mtime={cache_mtime}, expected≈{target_time}")
    except Exception as e:
        report(name, False, str(e))

    # ── 1d. Getattr on unopened file ──────────────────────────────────────
    name = "1d-getattr-unopened"
    try:
        # Place a file directly on the server that the client hasn't seen.
        srv_path = server_dir / "s1_getattr_only.txt"
        with open(str(srv_path), "wb") as f:
            f.write(b"server-only content")

        # stat via mount (client has never opened this file).
        st = os.stat(str(mount_dir / "s1_getattr_only.txt"))
        report(name, st.st_size == 19,
               f"size={st.st_size}, expected=19")
    except Exception as e:
        report(name, False, str(e))

# ──────────────────────────────────────────────────────────────────────────────
#  Stage 2: Mode-Based Freshness (Section 7.1.6 Optimization)
# ──────────────────────────────────────────────────────────────────────────────

def stage2(dirs):
    print()
    print("=" * 60)
    print("  STAGE 2: Mode-Based Freshness")
    print("=" * 60)

    server_dir = dirs["server"]
    cache_dir  = dirs["cache"]
    mount_dir  = dirs["mount"]

    # ── 2a. Reader Optimization ───────────────────────────────────────────
    #   Open O_RDONLY, modify server directly, client should still see
    #   cached data within grace period, then new data after expiry.
    name_cached = "2a-reader-cached-within-grace"
    name_fresh  = "2a-reader-fresh-after-grace"
    try:
        fname = "s2_reader.txt"

        # Create file via mount so server has it.
        p = str(mount_dir / fname)
        fd = os.open(p, os.O_CREAT | os.O_RDWR)
        os.write(fd, b"original-data")
        os.close(fd)
        time.sleep(0.5)

        # Read once to warm cache and set Tc.
        fd_r = os.open(p, os.O_RDONLY)
        initial_read = os.read(fd_r, 4096)
        os.close(fd_r)

        # Modify the server file directly (bypass mount).
        with open(str(server_dir / fname), "wb") as f:
            f.write(b"updated-server-data")
        # Also advance mtime so the handshake detects the change.
        future = time.time() + 2
        os.utime(str(server_dir / fname), (future, future))

        # Read immediately (within grace period) – should still see original.
        fd_r2 = os.open(p, os.O_RDONLY)
        cached_read = os.read(fd_r2, 4096)
        os.close(fd_r2)

        report(name_cached, cached_read == b"original-data",
               f"got={cached_read!r}")

        # Wait for cache interval to expire.
        print(f"    ... sleeping {CACHE_INTERVAL + 1}s for grace expiry ...")
        time.sleep(CACHE_INTERVAL + 1)

        fd_r3 = os.open(p, os.O_RDONLY)
        fresh_read = os.read(fd_r3, 4096)
        os.close(fd_r3)

        report(name_fresh, fresh_read == b"updated-server-data",
               f"got={fresh_read!r}")
    except Exception as e:
        report(name_cached, False, str(e))
        report(name_fresh, False, "skipped (prior error)")

    # ── 2b. Writer Optimization ───────────────────────────────────────────
    #   Open O_RDWR, write locally, read same handle – must return local
    #   data without contacting the server even after >cache_interval.
    name = "2b-writer-local-read"
    try:
        fname = "s2_writer.txt"
        p = str(mount_dir / fname)

        fd = os.open(p, os.O_CREAT | os.O_RDWR)
        os.write(fd, b"writer-initial")

        # Sneak-change the server file directly.
        with open(str(server_dir / fname), "wb") as f:
            f.write(b"server-sneaky-change")

        # Sleep well beyond cache interval.
        print(f"    ... sleeping {CACHE_INTERVAL + 5}s (writer optimization) ...")
        time.sleep(CACHE_INTERVAL + 5)

        # pread on the same fd at offset 0 – must see local data.
        data = os.pread(fd, 4096, 0)
        os.close(fd)

        report(name, data == b"writer-initial",
               f"got={data!r}")
    except Exception as e:
        report(name, False, str(e))

# ──────────────────────────────────────────────────────────────────────────────
#  Stage 3: SWMR & Transfer Atomicity (Section 7.1.2 / 7.2.4)
# ──────────────────────────────────────────────────────────────────────────────

def stage3(dirs):
    print()
    print("=" * 60)
    print("  STAGE 3: SWMR & Transfer Atomicity")
    print("=" * 60)

    server_dir = dirs["server"]
    cache_dir  = dirs["cache"]
    mount_dir  = dirs["mount"]

    # ── 3a. The Lockout (EMFILE) ──────────────────────────────────────────
    #   Open a file for writing.  From the same client, try to open the
    #   same file again.  The client EMFILE guard should reject it.
    name = "3a-swmr-emfile-lockout"
    try:
        fname = "s3_lockout.txt"
        p = str(mount_dir / fname)

        fd_w = os.open(p, os.O_CREAT | os.O_RDWR)
        os.write(fd_w, b"locked-content")

        # Second open from same client → EMFILE.
        try:
            fd_w2 = os.open(p, os.O_WRONLY)
            os.close(fd_w2)
            report(name, False, "second open succeeded (expected EMFILE)")
        except OSError as e2:
            report(name, e2.errno == errno.EMFILE,
                   f"errno={e2.errno} ({os.strerror(e2.errno)})")

        os.close(fd_w)
    except Exception as e:
        report(name, False, str(e))

    # ── 3b. EMFILE on RDONLY too ──────────────────────────────────────────
    #   Even opening O_RDONLY on an already-open file should return EMFILE.
    name = "3b-swmr-emfile-rdonly"
    try:
        fname = "s3_lockout_rd.txt"
        p = str(mount_dir / fname)

        fd_w = os.open(p, os.O_CREAT | os.O_RDWR)
        os.write(fd_w, b"content")

        try:
            fd_r = os.open(p, os.O_RDONLY)
            os.close(fd_r)
            report(name, False, "second open(RDONLY) succeeded (expected EMFILE)")
        except OSError as e2:
            report(name, e2.errno == errno.EMFILE,
                   f"errno={e2.errno} ({os.strerror(e2.errno)})")

        os.close(fd_w)
    except Exception as e:
        report(name, False, str(e))

    # ── 3c. Mknod on existing path fails EEXIST ──────────────────────────
    name = "3c-mknod-eexist"
    try:
        fname = "s3_lockout.txt"  # already created above
        p = str(mount_dir / fname)

        try:
            os.mknod(p, 0o100644)
            report(name, False, "mknod succeeded on existing path")
        except OSError as e2:
            report(name, e2.errno == errno.EEXIST,
                   f"errno={e2.errno} ({os.strerror(e2.errno)})")
    except Exception as e:
        report(name, False, str(e))

    # ── 3d. Atomic large-file round-trip ──────────────────────────────────
    #   Write a 10 MB file, close (uploads), read back, verify integrity.
    name = "3d-atomic-large-file"
    try:
        fname = "s3_large.bin"
        p = str(mount_dir / fname)
        size = 10 * 1024 * 1024  # 10 MB
        pattern = b"ABCDEFGH" * (size // 8)

        fd = os.open(p, os.O_CREAT | os.O_RDWR)
        written = 0
        while written < len(pattern):
            chunk = min(65536, len(pattern) - written)
            n = os.pwrite(fd, pattern[written:written+chunk], written)
            written += n
        os.close(fd)
        time.sleep(0.5)

        # Read it back via a fresh open.
        fd2 = os.open(p, os.O_RDONLY)
        read_buf = b""
        off = 0
        while off < len(pattern):
            chunk = os.pread(fd2, 65536, off)
            if not chunk:
                break
            read_buf += chunk
            off += len(chunk)
        os.close(fd2)

        report(name, read_buf == pattern,
               f"written={len(pattern)}, read={len(read_buf)}")
    except Exception as e:
        report(name, False, str(e))

    # ── 3e. Server file matches after upload ──────────────────────────────
    name = "3e-server-integrity"
    try:
        srv_path = str(dirs["server"] / "s3_large.bin")
        with open(srv_path, "rb") as f:
            srv_data = f.read()
        size = 10 * 1024 * 1024
        expected = b"ABCDEFGH" * (size // 8)
        report(name, srv_data == expected,
               f"server len={len(srv_data)}, expected={len(expected)}")
    except Exception as e:
        report(name, False, str(e))

# ──────────────────────────────────────────────────────────────────────────────
#  Stage 4: Fsync & Release (Section 7.1.5 / 7.2.5 / 7.2.6)
# ──────────────────────────────────────────────────────────────────────────────

def stage4(dirs):
    print()
    print("=" * 60)
    print("  STAGE 4: Fsync & Release")
    print("=" * 60)

    server_dir = dirs["server"]
    cache_dir  = dirs["cache"]
    mount_dir  = dirs["mount"]

    # ── 4a. Fsync flushes to server immediately ──────────────────────────
    name = "4a-fsync-flush"
    try:
        fname = "s4_fsync.txt"
        p = str(mount_dir / fname)

        fd = os.open(p, os.O_CREAT | os.O_RDWR)
        os.write(fd, b"fsync-payload")

        # fsync should upload immediately.
        os.fsync(fd)
        time.sleep(0.3)

        srv_path = server_dir / fname
        ok = srv_path.exists()
        if ok:
            with open(str(srv_path), "rb") as f:
                srv_data = f.read()
            ok = (srv_data == b"fsync-payload")
            detail = f"server data={srv_data!r}"
        else:
            detail = "file not on server"

        os.close(fd)
        report(name, ok, detail)
    except Exception as e:
        report(name, False, str(e))

    # ── 4b. Release syncs to server ───────────────────────────────────────
    name = "4b-release-sync"
    try:
        fname = "s4_release.txt"
        p = str(mount_dir / fname)

        fd = os.open(p, os.O_CREAT | os.O_RDWR)
        os.write(fd, b"release-payload")
        os.close(fd)  # release triggers upload

        time.sleep(0.5)
        srv_path = server_dir / fname
        ok = srv_path.exists()
        if ok:
            with open(str(srv_path), "rb") as f:
                srv_data = f.read()
            ok = (srv_data == b"release-payload")
            detail = f"server data={srv_data!r}"
        else:
            detail = "file not on server"

        report(name, ok, detail)
    except Exception as e:
        report(name, False, str(e))

    # ── 4c. Fsync on read-only fd ─────────────────────────────────────────
    name = "4c-fsync-rdonly"
    try:
        fname = "s4_fsync_rd.txt"
        p = str(mount_dir / fname)
        # Make sure file exists.
        fd_create = os.open(p, os.O_CREAT | os.O_RDWR)
        os.write(fd_create, b"readonly-test")
        os.close(fd_create)

        fd_r = os.open(p, os.O_RDONLY)
        try:
            os.fsync(fd_r)
            # If fsync succeeds on rdonly, FUSE/kernel may swallow the
            # EBADF before it reaches userspace. Accept both outcomes.
            report(name, True, "fsync did not error (kernel may swallow)")
        except OSError as e2:
            report(name, e2.errno == errno.EBADF,
                   f"errno={e2.errno} ({os.strerror(e2.errno)})")
        finally:
            os.close(fd_r)
    except Exception as e:
        report(name, False, str(e))

    # ── 4d. EMFILE retry (Section 7.2.6) ─────────────────────────────────
    #   Close a writer and immediately re-open.  The first attempt may
    #   get EMFILE if the release hasn't finished.  Retry until success.
    name = "4d-emfile-retry"
    try:
        fname = "s4_emfile.txt"
        p = str(mount_dir / fname)

        fd = os.open(p, os.O_CREAT | os.O_RDWR)
        os.write(fd, b"emfile-test")
        os.close(fd)

        # Immediately try to reopen in a tight loop.
        opened = False
        attempts = 0
        for attempt in range(20):
            attempts = attempt + 1
            try:
                fd2 = os.open(p, os.O_RDONLY)
                os.close(fd2)
                opened = True
                break
            except OSError as e2:
                if e2.errno == errno.EMFILE:
                    time.sleep(0.1)
                    continue
                else:
                    raise
        report(name, opened, f"opened after {attempts} attempt(s)")
    except Exception as e:
        report(name, False, str(e))

    # ── 4e. Fsync → further write → release ──────────────────────────────
    #   Verify intermediate and final server states.
    name = "4e-fsync-write-release"
    try:
        fname = "s4_fsync_wr.txt"
        p = str(mount_dir / fname)

        fd = os.open(p, os.O_CREAT | os.O_RDWR)
        os.write(fd, b"first-")
        os.fsync(fd)
        time.sleep(0.3)

        # Check intermediate state on server.
        with open(str(server_dir / fname), "rb") as f:
            mid_data = f.read()

        os.pwrite(fd, b"second", len(b"first-"))
        os.close(fd)  # release uploads final state

        time.sleep(0.5)
        with open(str(server_dir / fname), "rb") as f:
            final_data = f.read()

        ok = (mid_data == b"first-") and (final_data == b"first-second")
        report(name, ok,
               f"mid={mid_data!r}, final={final_data!r}")
    except Exception as e:
        report(name, False, str(e))

    # ── 4f. Multiple fsync calls ──────────────────────────────────────────
    name = "4f-multiple-fsync"
    try:
        fname = "s4_multi_fsync.txt"
        p = str(mount_dir / fname)

        fd = os.open(p, os.O_CREAT | os.O_RDWR)
        os.write(fd, b"AAA")
        os.fsync(fd)
        time.sleep(0.2)

        with open(str(server_dir / fname), "rb") as f:
            snap1 = f.read()

        os.pwrite(fd, b"BBB", 3)
        os.fsync(fd)
        time.sleep(0.2)

        with open(str(server_dir / fname), "rb") as f:
            snap2 = f.read()

        os.close(fd)

        ok = (snap1 == b"AAA") and (snap2 == b"AAABBB")
        report(name, ok, f"snap1={snap1!r}, snap2={snap2!r}")
    except Exception as e:
        report(name, False, str(e))

# ──────────────────────────────────────────────────────────────────────────────
#  Main
# ──────────────────────────────────────────────────────────────────────────────

def main():
    server_proc = client_proc = None
    dirs = None

    try:
        server_proc, client_proc, dirs = setup()

        stage1(dirs)
        stage2(dirs)
        stage3(dirs)
        stage4(dirs)

    except Exception as e:
        print(f"\n❌ FATAL EXCEPTION: {e}")
        import traceback
        traceback.print_exc()
    finally:
        if dirs:
            teardown(server_proc, client_proc, dirs["mount"])
        else:
            # Best-effort cleanup.
            terminate_proc(client_proc)
            terminate_proc(server_proc)
            fusermount_u(Path("/tmp") / os.environ.get("USER", "user")
                         / "watdfs_p2_test" / "mount")

    rc = print_summary()
    sys.exit(rc)

if __name__ == "__main__":
    main()
