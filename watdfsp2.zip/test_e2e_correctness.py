#!/usr/bin/env python3
"""
WatDFS E2E Correctness Tests
============================
Focused tests that catch the specific bugs Marmoset found:
1. Server FH corruption → Permission denied on reopen same file
2. SWMR state poisoning from failed close() 
3. Read-only freshness not working for open files
4. Basic open/close/reopen flows

These tests use the SAME filename across multiple operations to trigger
the server-side SWMR state corruption that our comprehensive test missed.
"""

import os
import re
import sys
import time
import errno
import subprocess
from pathlib import Path

# ──────────────────────────────────────────────────────────────────────────────
#  Setup utilities (same as other tests)
# ──────────────────────────────────────────────────────────────────────────────

CACHE_INTERVAL = 2  # shorter for faster tests

def run(cmd, **kwargs):
    return subprocess.run(cmd, text=True, capture_output=True, **kwargs)

def is_mounted(mount_dir: Path) -> bool:
    cp = subprocess.run(["mountpoint", "-q", str(mount_dir)])
    return cp.returncode == 0

def fusermount_u(mount_dir: Path):
    subprocess.run(["fusermount", "-u", str(mount_dir)],
                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

def terminate_proc(p):
    if p is None or p.poll() is not None:
        return
    try:
        p.terminate()
        p.wait(timeout=2)
    except Exception:
        try:
            p.kill()
        except Exception:
            pass

def wait_for_mount(mount_dir: Path, timeout_s: float = 5.0) -> bool:
    t0 = time.time()
    while time.time() - t0 < timeout_s:
        if is_mounted(mount_dir):
            return True
        time.sleep(0.05)
    return False

def wait_for_server_env(server_proc, timeout_s: float = 5.0):
    addr = port = None
    buf = ""
    t0 = time.time()
    while time.time() - t0 < timeout_s:
        line = server_proc.stdout.readline() if server_proc.stdout else ""
        if line:
            buf += line
            m1 = re.search(r"export\s+SERVER_ADDRESS\s*=\s*([^\s]+)", buf)
            m2 = re.search(r"export\s+SERVER_PORT\s*=\s*([0-9]+)", buf)
            if m1:
                addr = m1.group(1).strip()
            if m2:
                port = m2.group(1).strip()
            if addr and port:
                return addr, port, buf
        else:
            time.sleep(0.05)
    return addr, port, buf

# ──────────────────────────────────────────────────────────────────────────────
#  Test framework
# ──────────────────────────────────────────────────────────────────────────────

results = []

def test(name, func, dirs):
    """Run a single test function and record result."""
    try:
        func(dirs)
        print(f"✅ PASS: {name}")
        results.append((name, True, ""))
    except Exception as e:
        print(f"❌ FAIL: {name} → {e}")
        results.append((name, False, str(e)))

def print_summary():
    total = len(results)
    passed = sum(1 for _, p, _ in results if p)
    failed = total - passed
    print(f"\n{'='*60}")
    print(f"SUMMARY: {passed}/{total} passed, {failed} failed")
    if failed:
        print("FAILED tests:")
        for name, p, detail in results:
            if not p:
                print(f"  - {name}: {detail}")
    print(f"{'='*60}")
    return 0 if failed == 0 else 1

def setup():
    """Build, start server+client, return (server_proc, client_proc, dirs)."""
    here = Path(".").resolve()
    
    # Build
    print("[setup] Building...")
    build = run(["make", "clean", "all"])
    if build.returncode != 0:
        print("BUILD FAILED ❌")
        print(build.stdout, build.stderr)
        sys.exit(1)
    print("[setup] Build OK ✅")

    # Dirs
    base = Path(f"/tmp/{os.environ.get('USER', 'user')}/watdfs_e2e_test")
    server_dir = base / "server"
    cache_dir  = base / "cache" 
    mount_dir  = base / "mount"
    logs_dir   = base / "logs"

    for d in [server_dir, cache_dir, mount_dir, logs_dir]:
        if d.exists() and d == mount_dir:
            fusermount_u(d)
        run(["rm", "-rf", str(d)])
        d.mkdir(parents=True, exist_ok=True)

    # Start server
    print("[setup] Starting server...")
    server_err = (logs_dir / "server.err").open("w")
    server_proc = subprocess.Popen(
        [str(here / "watdfs_server"), str(server_dir)],
        stdout=subprocess.PIPE, stderr=server_err, text=True, bufsize=1)

    addr, port, captured = wait_for_server_env(server_proc)
    if not addr:
        addr = "localhost"
    if not port:
        print("❌ No SERVER_PORT")
        terminate_proc(server_proc)
        sys.exit(2)

    # Start client
    print(f"[setup] Starting client (cache_interval={CACHE_INTERVAL}s)...")
    env = os.environ.copy()
    env.update({
        "SERVER_ADDRESS": addr,
        "SERVER_PORT": str(port),
        "CACHE_INTERVAL_SEC": str(CACHE_INTERVAL)
    })

    client_out = (logs_dir / "client.out").open("w")
    client_err = (logs_dir / "client.err").open("w")
    client_proc = subprocess.Popen(
        [str(here / "watdfs_client"), "-s", "-f", "-o", "direct_io", 
         str(cache_dir), str(mount_dir)],
        stdout=client_out, stderr=client_err, env=env, text=True, bufsize=1)

    if not wait_for_mount(mount_dir):
        print("❌ Mount failed")
        terminate_proc(client_proc)
        terminate_proc(server_proc)
        sys.exit(3)

    print("[setup] Mount active ✅\n")
    return server_proc, client_proc, {
        "server": server_dir, "cache": cache_dir, 
        "mount": mount_dir, "logs": logs_dir
    }

def teardown(server_proc, client_proc, mount_dir):
    print("\n[teardown] Cleaning up...")
    fusermount_u(mount_dir)
    time.sleep(0.2)
    terminate_proc(client_proc)
    terminate_proc(server_proc)

# ──────────────────────────────────────────────────────────────────────────────
#  Core correctness tests
# ──────────────────────────────────────────────────────────────────────────────

def test_basic_create_reopen(dirs):
    """Test basic create → close → reopen flow on same file."""
    mount_dir = dirs["mount"]
    server_dir = dirs["server"]
    
    fname = "basic_test.txt" 
    p = str(mount_dir / fname)
    
    # Create file
    fd1 = os.open(p, os.O_CREAT | os.O_RDWR)
    os.write(fd1, b"test-data")
    os.close(fd1)
    
    # Verify server has it
    assert (server_dir / fname).exists(), "File not created on server"
    
    # Reopen same file - this should work
    fd2 = os.open(p, os.O_RDWR) 
    data = os.read(fd2, 100)
    os.close(fd2)
    
    assert data == b"test-data", f"Got {data!r}, expected b'test-data'"

def test_marmoset_asdf_pattern(dirs):
    """Reproduce exact Marmoset failure: asdf.txt reuse."""
    mount_dir = dirs["mount"]
    server_dir = dirs["server"]
    
    fname = "asdf.txt"  # Same filename Marmoset uses
    p = str(mount_dir / fname)
    
    # First operation
    fd1 = os.open(p, os.O_CREAT | os.O_RDWR)
    os.write(fd1, b"first")
    os.close(fd1)
    time.sleep(0.1)
    
    # Second operation on SAME file (like Marmoset tests)
    fd2 = os.open(p, os.O_RDWR)  # This gets Permission denied if SWMR poisoned
    os.write(fd2, b"second")
    os.close(fd2)
    
    # Third operation 
    fd3 = os.open(p, os.O_RDONLY)
    data = os.read(fd3, 100)
    os.close(fd3)
    
    assert data == b"second", f"Got {data!r}, expected b'second'"

def test_multiple_modes_same_file(dirs):
    """Test different open modes on same file sequentially."""
    mount_dir = dirs["mount"]
    fname = "modes_test.txt"
    p = str(mount_dir / fname)
    
    # Create
    fd1 = os.open(p, os.O_CREAT | os.O_RDWR)
    os.write(fd1, b"initial") 
    os.close(fd1)
    
    # Read-only
    fd2 = os.open(p, os.O_RDONLY)
    data1 = os.read(fd2, 100)
    os.close(fd2)
    assert data1 == b"initial"
    
    # Write-only
    fd3 = os.open(p, os.O_WRONLY)
    os.write(fd3, b"modified")
    os.close(fd3)
    
    # Read-write again
    fd4 = os.open(p, os.O_RDWR)
    data2 = os.read(fd4, 100)
    os.close(fd4)
    assert data2 == b"modified"

def test_server_fh_not_corrupted(dirs):
    """Verify server-side operations don't get confused by client FD numbers."""
    mount_dir = dirs["mount"]
    server_dir = dirs["server"]
    
    fname = "server_fh_test.txt"
    p = str(mount_dir / fname)
    
    # Create with specific content
    fd1 = os.open(p, os.O_CREAT | os.O_RDWR)
    test_data = b"0123456789" * 100  # 1000 bytes
    os.write(fd1, test_data)
    os.close(fd1)
    time.sleep(0.3)
    
    # Verify server has exact content
    with open(str(server_dir / fname), "rb") as f:
        server_data = f.read()
    assert server_data == test_data, "Server data corrupted"
    
    # Reopen and modify
    fd2 = os.open(p, os.O_RDWR)
    os.pwrite(fd2, b"XXXX", 500)  # Modify middle
    os.close(fd2)
    time.sleep(0.3)
    
    # Server should reflect the change
    with open(str(server_dir / fname), "rb") as f:
        server_data2 = f.read()
    expected = test_data[:500] + b"XXXX" + test_data[504:]
    assert server_data2 == expected, "Server not updated correctly"

def test_readonly_freshness_when_open(dirs):
    """Test the specific freshness bug: open O_RDONLY doesn't refresh on getattr."""
    mount_dir = dirs["mount"] 
    server_dir = dirs["server"]
    cache_dir = dirs["cache"]
    
    fname = "freshness_test.txt"
    p_mount = str(mount_dir / fname)
    p_server = str(server_dir / fname)
    p_cache = str(cache_dir / fname)
    
    # Create initial file
    fd1 = os.open(p_mount, os.O_CREAT | os.O_RDWR)
    os.write(fd1, b"original")
    os.close(fd1)
    time.sleep(0.3)
    
    # Open read-only (this sets Tc)
    fd_ro = os.open(p_mount, os.O_RDONLY) 
    data1 = os.read(fd_ro, 100)
    assert data1 == b"original"
    
    # Modify server directly (bypass client)
    with open(p_server, "wb") as f:
        f.write(b"modified-by-server")
    # Advance server mtime so handshake will detect change
    future_time = time.time() + 10
    os.utime(p_server, (future_time, future_time))
    
    # Sleep past cache interval
    print(f"  ... sleeping {CACHE_INTERVAL + 1}s for cache expiry ...")
    time.sleep(CACHE_INTERVAL + 1)
    
    # Do getattr on the OPEN file - should trigger freshness check
    st = os.stat(p_mount)
    assert st.st_size == len(b"modified-by-server"), "getattr should have refreshed cache"
    
    # Read from same open FD - should see new data
    os.lseek(fd_ro, 0, os.SEEK_SET)
    data2 = os.read(fd_ro, 100)
    os.close(fd_ro)
    
    assert data2 == b"modified-by-server", f"Expected fresh data, got {data2!r}"

def test_create_with_flags(dirs):
    """Test various O_CREAT combinations that Marmoset tests."""
    mount_dir = dirs["mount"]
    
    # O_CREAT | O_RDWR
    p1 = str(mount_dir / "create_rdwr.txt")
    fd1 = os.open(p1, os.O_CREAT | os.O_RDWR)
    os.write(fd1, b"rdwr")
    os.close(fd1)
    
    # O_CREAT | O_WRONLY  
    p2 = str(mount_dir / "create_wronly.txt")
    fd2 = os.open(p2, os.O_CREAT | os.O_WRONLY)
    os.write(fd2, b"wronly")
    os.close(fd2)
    
    # Verify both can be reopened
    fd1b = os.open(p1, os.O_RDONLY)
    data1 = os.read(fd1b, 100)
    os.close(fd1b)
    assert data1 == b"rdwr"
    
    fd2b = os.open(p2, os.O_RDONLY) 
    data2 = os.read(fd2b, 100)
    os.close(fd2b)
    assert data2 == b"wronly"

def test_truncate_reopen_pattern(dirs):
    """Test truncate operations that Marmoset includes.""" 
    mount_dir = dirs["mount"]
    server_dir = dirs["server"]
    
    fname = "trunc_test.txt"
    p = str(mount_dir / fname)
    
    # Create with data
    fd1 = os.open(p, os.O_CREAT | os.O_RDWR)
    os.write(fd1, b"A" * 1000)
    os.close(fd1)
    
    # Truncate while closed (should use truncate sandwich)
    os.truncate(p, 500)
    
    # Reopen - should work and see truncated size
    fd2 = os.open(p, os.O_RDONLY)
    data = os.read(fd2, 1000)
    os.close(fd2)
    
    assert len(data) == 500, f"Expected 500 bytes, got {len(data)}"
    assert data == b"A" * 500, "Truncated data incorrect"
    
    # Server should also be truncated
    srv_size = os.stat(str(server_dir / fname)).st_size
    assert srv_size == 500, f"Server size {srv_size}, expected 500"

def test_append_mode_pattern(dirs):
    """Test O_APPEND that Marmoset includes."""
    mount_dir = dirs["mount"]
    
    fname = "append_test.txt" 
    p = str(mount_dir / fname)
    
    # Create initial file
    fd1 = os.open(p, os.O_CREAT | os.O_RDWR)
    os.write(fd1, b"initial")
    os.close(fd1)
    
    # Open in append mode
    fd2 = os.open(p, os.O_WRONLY | os.O_APPEND)
    os.write(fd2, b"-appended")
    os.close(fd2)
    
    # Read back
    fd3 = os.open(p, os.O_RDONLY)
    data = os.read(fd3, 100)
    os.close(fd3)
    
    assert data == b"initial-appended", f"Got {data!r}, expected b'initial-appended'"

# ──────────────────────────────────────────────────────────────────────────────
#  Main
# ──────────────────────────────────────────────────────────────────────────────

def main():
    print("WatDFS E2E Correctness Tests")
    print("=" * 40)
    
    server_proc = client_proc = None
    dirs = None
    
    try:
        server_proc, client_proc, dirs = setup()
        
        # Run all tests  
        test("basic_create_reopen", test_basic_create_reopen, dirs)
        test("marmoset_asdf_pattern", test_marmoset_asdf_pattern, dirs) 
        test("multiple_modes_same_file", test_multiple_modes_same_file, dirs)
        test("server_fh_not_corrupted", test_server_fh_not_corrupted, dirs)
        test("readonly_freshness_when_open", test_readonly_freshness_when_open, dirs)
        test("create_with_flags", test_create_with_flags, dirs)
        test("truncate_reopen_pattern", test_truncate_reopen_pattern, dirs)
        test("append_mode_pattern", test_append_mode_pattern, dirs)
        
    except Exception as e:
        print(f"\n❌ FATAL: {e}")
        import traceback
        traceback.print_exc()
    finally:
        if dirs:
            teardown(server_proc, client_proc, dirs["mount"])
        else:
            terminate_proc(client_proc)
            terminate_proc(server_proc)
    
    return print_summary()

if __name__ == "__main__":
    sys.exit(main())