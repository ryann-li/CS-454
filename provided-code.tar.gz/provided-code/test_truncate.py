#!/usr/bin/env python3
import os
import re
import sys
import time
import errno
import subprocess
from pathlib import Path

# --- Helper Functions (Same as other tests) ---

def run(cmd, **kwargs):
    return subprocess.run(cmd, text=True, capture_output=True, **kwargs)

def is_mounted(mount_dir: Path) -> bool:
    cp = subprocess.run(["mountpoint", "-q", str(mount_dir)])
    return cp.returncode == 0

def fusermount_u(mount_dir: Path):
    subprocess.run(
        ["fusermount", "-u", str(mount_dir)],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )

def terminate_proc(p: subprocess.Popen):
    if p is None:
        return
    if p.poll() is not None:
        return
    try:
        p.terminate()
        p.wait(timeout=2)
    except Exception:
        try:
            p.kill()
        except Exception:
            pass

def wait_for_mount(mount_dir: Path, timeout_s: float = 5.0) -> bool:
    t0 = time.time()
    while time.time() - t0 < timeout_s:
        if is_mounted(mount_dir):
            return True
        time.sleep(0.05)
    return False

def wait_for_server_env(server_proc: subprocess.Popen, timeout_s: float = 3.0):
    addr = None
    port = None
    buf = ""

    t0 = time.time()
    while time.time() - t0 < timeout_s:
        line = server_proc.stdout.readline() if server_proc.stdout else ""
        if line:
            buf += line
            m1 = re.search(r"export\s+SERVER_ADDRESS\s*=\s*([^\s]+)", buf)
            m2 = re.search(r"export\s+SERVER_PORT\s*=\s*([0-9]+)", buf)
            if m1:
                addr = m1.group(1).strip()
            if m2:
                port = m2.group(1).strip()
            if addr and port:
                return addr, port, buf
        else:
            time.sleep(0.05)

    return addr, port, buf

# --- Test Logic ---

def main():
    here = Path(".").resolve()

    # 1. Build
    print("[1/3] Building...")
    build = run(["make", "clean", "all"])
    if build.returncode != 0:
        print("BUILD FAILED ❌")
        print(build.stdout)
        print(build.stderr)
        sys.exit(1)
    print("Build OK ✅")

    server_bin = here / "watdfs_server"
    client_bin = here / "watdfs_client"

    base = Path(f"/tmp/{os.environ.get('USER','user')}/watdfs_truncate_test")
    server_dir = base / "server"
    cache_dir = base / "cache"
    mount_dir = base / "mount"
    logs_dir = base / "logs"

    # Reset test dirs
    for d in [server_dir, cache_dir, mount_dir, logs_dir]:
        if d.exists() and d == mount_dir:
            fusermount_u(d)
        run(["rm", "-rf", str(d)])
        d.mkdir(parents=True, exist_ok=True)

    print(f"[2/3] Starting services in {base}...")
    
    server_proc = None
    client_proc = None

    try:
        # Start Server
        server_err = (logs_dir / "server.err").open("w")
        server_proc = subprocess.Popen(
            [str(server_bin), str(server_dir)],
            stdout=subprocess.PIPE,
            stderr=server_err,
            text=True,
            bufsize=1,
        )

        addr, port, captured = wait_for_server_env(server_proc)
        if not addr or not port:
            addr = os.environ.get("SERVER_ADDRESS", "localhost")
            port = os.environ.get("SERVER_PORT")

        if not port:
            print("❌ Could not get port from server")
            sys.exit(2)

        # Start Client
        env = os.environ.copy()
        env["SERVER_ADDRESS"] = addr
        env["SERVER_PORT"] = str(port)

        client_out = (logs_dir / "client.out").open("w")
        client_err = (logs_dir / "client.err").open("w")

        client_proc = subprocess.Popen(
            [str(client_bin), "-s", "-f", "-o", "direct_io", str(cache_dir), str(mount_dir)],
            stdout=client_out,
            stderr=client_err,
            env=env,
            text=True,
            bufsize=1,
        )

        if not wait_for_mount(mount_dir):
            print("❌ Mount failed")
            sys.exit(3)
        
        print("Mount active ✅")

        # --- TRUNCATE TESTS ---
        print("\n[3/3] Running Truncate Tests...")

        # Test 1: Truncate to shrink file
        print("  Test 1: Shrink file with truncate...", end="", flush=True)
        test_file1 = mount_dir / "shrink.txt"
        original_data = b"This is a long file with lots of content that will be shortened"
        
        with open(test_file1, "wb") as f:
            f.write(original_data)
        
        # Truncate to 20 bytes
        os.truncate(str(test_file1), 20)
        
        with open(test_file1, "rb") as f:
            truncated_data = f.read()
        
        expected = original_data[:20]
        if truncated_data != expected:
            print(f" FAILED ❌ (Expected {expected}, got {truncated_data})")
            sys.exit(1)
        
        # Verify file size
        stat_info = os.stat(str(test_file1))
        if stat_info.st_size != 20:
            print(f" FAILED ❌ (File size is {stat_info.st_size}, expected 20)")
            sys.exit(1)
        print(" OK ✅")

        # Test 2: Truncate to extend file (should fill with zeros)
        print("  Test 2: Extend file with truncate...", end="", flush=True)
        test_file2 = mount_dir / "extend.txt"
        small_data = b"Small"
        
        with open(test_file2, "wb") as f:
            f.write(small_data)
        
        # Truncate to extend to 20 bytes
        os.truncate(str(test_file2), 20)
        
        with open(test_file2, "rb") as f:
            extended_data = f.read()
        
        expected = small_data + b"\x00" * (20 - len(small_data))
        if extended_data != expected:
            print(f" FAILED ❌ (Expected {expected}, got {extended_data})")
            sys.exit(1)
        
        # Verify file size
        stat_info = os.stat(str(test_file2))
        if stat_info.st_size != 20:
            print(f" FAILED ❌ (File size is {stat_info.st_size}, expected 20)")
            sys.exit(1)
        print(" OK ✅")

        # Test 3: Truncate to zero (empty file)
        print("  Test 3: Truncate to zero...", end="", flush=True)
        test_file3 = mount_dir / "zero.txt"
        some_data = b"This will all be deleted"
        
        with open(test_file3, "wb") as f:
            f.write(some_data)
        
        # Truncate to 0 bytes
        os.truncate(str(test_file3), 0)
        
        with open(test_file3, "rb") as f:
            zero_data = f.read()
        
        if zero_data != b"":
            print(f" FAILED ❌ (Expected empty, got {zero_data})")
            sys.exit(1)
        
        # Verify file size
        stat_info = os.stat(str(test_file3))
        if stat_info.st_size != 0:
            print(f" FAILED ❌ (File size is {stat_info.st_size}, expected 0)")
            sys.exit(1)
        print(" OK ✅")

        # Test 4: Truncate same size (should be no-op)
        print("  Test 4: Truncate same size...", end="", flush=True)
        test_file4 = mount_dir / "same.txt"
        same_data = b"Exactly 15 byte"  # 15 bytes
        
        with open(test_file4, "wb") as f:
            f.write(same_data)
        
        # Truncate to same size
        os.truncate(str(test_file4), 15)
        
        with open(test_file4, "rb") as f:
            unchanged_data = f.read()
        
        if unchanged_data != same_data:
            print(f" FAILED ❌ (Expected {same_data}, got {unchanged_data})")
            sys.exit(1)
        print(" OK ✅")

        # Test 5: Truncate large file
        print("  Test 5: Truncate large file...", end="", flush=True)
        test_file5 = mount_dir / "large.txt"
        large_data = b"X" * 100000  # 100KB
        
        with open(test_file5, "wb") as f:
            f.write(large_data)
        
        # Truncate to much smaller size
        os.truncate(str(test_file5), 1000)
        
        with open(test_file5, "rb") as f:
            small_data = f.read()
        
        expected = b"X" * 1000
        if small_data != expected:
            print(f" FAILED ❌ (Data mismatch after truncating large file)")
            sys.exit(1)
        
        # Verify file size
        stat_info = os.stat(str(test_file5))
        if stat_info.st_size != 1000:
            print(f" FAILED ❌ (File size is {stat_info.st_size}, expected 1000)")
            sys.exit(1)
        print(" OK ✅")

        # Test 6: Truncate after write (os.truncate)
        print("  Test 6: Write then truncate...", end="", flush=True)
        test_file6 = mount_dir / "write_truncate.txt"
        
        # Write data first
        with open(test_file6, "wb") as f:
            f.write(b"Initial content")
        
        # Write more data
        with open(test_file6, "ab") as f:
            f.write(b" and additional content")
        
        # Now truncate it
        os.truncate(str(test_file6), 7)  # Keep first 7 bytes
        
        with open(test_file6, "rb") as f:
            result = f.read()
        
        expected = b"Initial"
        if result != expected:
            print(f" FAILED ❌ (Expected {expected}, got {result})")
            sys.exit(1)
        print(" OK ✅")

        # Test 7: Multiple truncates
        print("  Test 7: Multiple truncates...", end="", flush=True)
        test_file7 = mount_dir / "multiple.txt"
        multi_data = b"Start with this content for multiple truncate operations"
        
        with open(test_file7, "wb") as f:
            f.write(multi_data)
        
        # First truncate - shrink
        os.truncate(str(test_file7), 20)
        
        # Second truncate - extend 
        os.truncate(str(test_file7), 30)
        
        # Third truncate - shrink again
        os.truncate(str(test_file7), 10)
        
        with open(test_file7, "rb") as f:
            final_data = f.read()
        
        expected = multi_data[:10]
        if final_data != expected:
            print(f" FAILED ❌ (Expected {expected}, got {final_data})")
            sys.exit(1)
        
        # Verify file size
        stat_info = os.stat(str(test_file7))
        if stat_info.st_size != 10:
            print(f" FAILED ❌ (Final file size is {stat_info.st_size}, expected 10)")
            sys.exit(1)
        print(" OK ✅")

        # Test 8: Truncate non-existent file (should fail)
        print("  Test 8: Truncate non-existent file...", end="", flush=True)
        nonexistent = mount_dir / "does_not_exist.txt"
        
        try:
            os.truncate(str(nonexistent), 10)
            print(" FAILED ❌ (Should have failed)")
            sys.exit(1)
        except OSError as e:
            if e.errno == errno.ENOENT:
                print(" OK ✅")
            else:
                print(f" FAILED ❌ (Wrong error: {e})")
                sys.exit(1)

        print("\n🎉 All Truncate Tests Passed!")

    except Exception as e:
        print(f"\n❌ EXCEPTION: {e}")
        import traceback
        traceback.print_exc()
    finally:
        print("\nCleaning up...")
        if mount_dir.exists():
            fusermount_u(mount_dir)
        terminate_proc(client_proc)
        terminate_proc(server_proc)

if __name__ == "__main__":
    main()