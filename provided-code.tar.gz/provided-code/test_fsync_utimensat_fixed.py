#!/usr/bin/env python3
"""
Integration tests for WatDFS fsync and utimensat operations.
Tests the new FUSE operations to ensure they work correctly.
"""
import os
import re
import sys
import time
import errno
import subprocess
from pathlib import Path

# --- Helper Functions (Same as other tests) ---

def run(cmd, **kwargs):
    return subprocess.run(cmd, text=True, capture_output=True, **kwargs)

def is_mounted(mount_dir: Path) -> bool:
    cp = subprocess.run(["mountpoint", "-q", str(mount_dir)])
    return cp.returncode == 0

def fusermount_u(mount_dir: Path):
    subprocess.run(
        ["fusermount", "-u", str(mount_dir)],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )

def terminate_proc(p: subprocess.Popen):
    if p is None:
        return
    if p.poll() is not None:
        return
    try:
        p.terminate()
        p.wait(timeout=2)
    except Exception:
        try:
            p.kill()
        except Exception:
            pass

def wait_for_mount(mount_dir: Path, timeout_s: float = 5.0) -> bool:
    t0 = time.time()
    while time.time() - t0 < timeout_s:
        if is_mounted(mount_dir):
            return True
        time.sleep(0.05)
    return False

def wait_for_server_env(server_proc: subprocess.Popen, timeout_s: float = 3.0):
    addr = None
    port = None
    buf = ""

    t0 = time.time()
    while time.time() - t0 < timeout_s:
        line = server_proc.stdout.readline() if server_proc.stdout else ""
        if line:
            buf += line
            m1 = re.search(r"export\s+SERVER_ADDRESS\s*=\s*([^\s]+)", buf)
            m2 = re.search(r"export\s+SERVER_PORT\s*=\s*([0-9]+)", buf)
            if m1:
                addr = m1.group(1).strip()
            if m2:
                port = m2.group(1).strip()
            if addr and port:
                return addr, port, buf
        else:
            time.sleep(0.05)

    return addr, port, buf

# --- Test Logic ---

def main():
    here = Path(".").resolve()

    # 1. Build
    print("[1/3] Building...")
    build = run(["make", "clean", "all"])
    if build.returncode != 0:
        print("BUILD FAILED ❌")
        print(build.stdout)
        print(build.stderr)
        sys.exit(1)
    print("Build OK ✅")

    server_bin = here / "watdfs_server"
    client_bin = here / "watdfs_client"

    base = Path(f"/tmp/{os.environ.get('USER','user')}/watdfs_fsync_utimensat_test")
    server_dir = base / "server"
    cache_dir = base / "cache"
    mount_dir = base / "mount"
    logs_dir = base / "logs"

    # Reset test dirs
    for d in [server_dir, cache_dir, mount_dir, logs_dir]:
        if d.exists() and d == mount_dir:
            fusermount_u(d)
        run(["rm", "-rf", str(d)])
        d.mkdir(parents=True, exist_ok=True)

    print(f"[2/3] Starting services in {base}...")
    
    server_proc = None
    client_proc = None

    try:
        # Start Server
        server_err = (logs_dir / "server.err").open("w")
        server_proc = subprocess.Popen(
            [str(server_bin), str(server_dir)],
            stdout=subprocess.PIPE,
            stderr=server_err,
            text=True,
            bufsize=1,
        )

        addr, port, captured = wait_for_server_env(server_proc)
        if not addr or not port:
            addr = os.environ.get("SERVER_ADDRESS", "localhost")
            port = os.environ.get("SERVER_PORT")

        if not port:
            print("❌ Could not get port from server")
            sys.exit(2)

        # Start Client
        env = os.environ.copy()
        env["SERVER_ADDRESS"] = addr
        env["SERVER_PORT"] = str(port)

        client_out = (logs_dir / "client.out").open("w")
        client_err = (logs_dir / "client.err").open("w")

        client_proc = subprocess.Popen(
            [str(client_bin), "-s", "-f", "-o", "direct_io", str(cache_dir), str(mount_dir)],
            stdout=client_out,
            stderr=client_err,
            env=env,
            text=True,
            bufsize=1,
        )

        if not wait_for_mount(mount_dir):
            print("❌ Mount failed")
            sys.exit(3)
        
        print("Mount active ✅")

        # --- FSYNC AND UTIMENSAT TESTS ---
        print("\n[3/3] Running fsync and utimensat Tests...")

        # Test 1: Basic fsync functionality
        print("  Test 1: Basic fsync...", end="", flush=True)
        test_file = mount_dir / "fsync_test.txt"
        
        # Create and write to file
        with open(test_file, "w") as f:
            f.write("This file will be fsynced")
            f.flush()  # Flush to OS buffers
            os.fsync(f.fileno())  # Force sync to storage
        
        # File should exist and be readable
        with open(test_file, "r") as f:
            content = f.read()
        
        expected = "This file will be fsynced"
        if content != expected:
            print(f" FAILED ❌ (Expected '{expected}', got '{content}')")
            sys.exit(1)
        print(" OK ✅")
        
        # Test 2: fsync after multiple writes
        print("  Test 2: fsync after multiple writes...", end="", flush=True)
        append_file = mount_dir / "fsync_append.txt"
        
        with open(append_file, "w") as f:
            f.write("Line 1\n")
            f.flush()
            os.fsync(f.fileno())
            
            f.write("Line 2\n")
            f.flush()
            os.fsync(f.fileno())
            
            f.write("Line 3\n")
            f.flush()
            os.fsync(f.fileno())
        
        # Verify all content is present
        with open(append_file, "r") as f:
            lines = f.readlines()
        
        expected_lines = ["Line 1\n", "Line 2\n", "Line 3\n"]
        if lines != expected_lines:
            print(f" FAILED ❌ (Expected {expected_lines}, got {lines})")
            sys.exit(1)
        print(" OK ✅")
        
        # Test 3: fsync on different files
        print("  Test 3: fsync multiple files...", end="", flush=True)
        
        for i in range(3):
            file_path = mount_dir / f"fsync_multi_{i}.txt"
            with open(file_path, "w") as f:
                f.write(f"Content for file {i}")
                f.flush()
                os.fsync(f.fileno())
        
        # Verify all files
        for i in range(3):
            file_path = mount_dir / f"fsync_multi_{i}.txt"
            with open(file_path, "r") as f:
                content = f.read()
            expected = f"Content for file {i}"
            if content != expected:
                print(f" FAILED ❌ (File {i}: Expected '{expected}', got '{content}')")
                sys.exit(1)
        print(" OK ✅")

        # Test 4: Basic utimensat functionality
        print("  Test 4: Basic utimensat...", end="", flush=True)
        time_file = mount_dir / "time_test.txt"
        
        # Create file
        with open(time_file, "w") as f:
            f.write("Time modification test")
        
        # Set new times (1 hour in the future)
        new_time = time.time() + 3600
        os.utime(str(time_file), (new_time, new_time))
        
        # Check if times were updated
        updated_stat = os.stat(time_file)
        
        if abs(updated_stat.st_atime - new_time) > 1 or abs(updated_stat.st_mtime - new_time) > 1:
            print(f" FAILED ❌ (Times not updated correctly)")
            sys.exit(1)
        print(" OK ✅")
        
        # Test 5: Set only access time
        print("  Test 5: Update access time only...", end="", flush=True)
        access_file = mount_dir / "access_time_test.txt"
        
        with open(access_file, "w") as f:
            f.write("Access time test")
        
        # Get original times
        original_stat = os.stat(access_file)
        
        # Update only access time
        new_atime = time.time() + 1800  # 30 minutes in future
        os.utime(str(access_file), (new_atime, original_stat.st_mtime))
        
        updated_stat = os.stat(access_file)
        
        if abs(updated_stat.st_atime - new_atime) > 1:
            print(f" FAILED ❌ (Access time not updated correctly)")
            sys.exit(1)
        
        if abs(updated_stat.st_mtime - original_stat.st_mtime) > 1:
            print(f" FAILED ❌ (Modification time changed when it shouldn't)")
            sys.exit(1)
        
        print(" OK ✅")
        
        # Test 6: Set times to past
        print("  Test 6: Set times to past...", end="", flush=True)
        past_file = mount_dir / "past_time_test.txt"
        
        with open(past_file, "w") as f:
            f.write("Past time test")
        
        # Set times to 1 day ago
        past_time = time.time() - 86400  # 24 hours ago
        os.utime(str(past_file), (past_time, past_time))
        
        past_stat = os.stat(past_file)
        
        if abs(past_stat.st_atime - past_time) > 1 or abs(past_stat.st_mtime - past_time) > 1:
            print(f" FAILED ❌ (Past times not set correctly)")
            sys.exit(1)
        print(" OK ✅")
        
        # Test 7: Integration - Write, modify time, then fsync
        print("  Test 7: Write, modify time, fsync...", end="", flush=True)
        integration_file = mount_dir / "integration_test.txt"
        
        # Write initial content
        with open(integration_file, "w") as f:
            f.write("Initial content")
            f.flush()
            os.fsync(f.fileno())
        
        # Modify time
        custom_time = time.time() + 7200  # 2 hours in future
        os.utime(str(integration_file), (custom_time, custom_time))
        
        # Append more content and fsync again
        with open(integration_file, "a") as f:
            f.write("\nAppended content")
            f.flush()
            os.fsync(f.fileno())
        
        # Verify content
        with open(integration_file, "r") as f:
            content = f.read()
        
        expected_content = "Initial content\nAppended content"
        if content != expected_content:
            print(f" FAILED ❌ (Content mismatch)")
            sys.exit(1)
        
        print(" OK ✅")

        print("\n🎉 All fsync and utimensat Tests Passed!")

    except Exception as e:
        print(f"\n❌ EXCEPTION: {e}")
        import traceback
        traceback.print_exc()
    finally:
        print("\nCleaning up...")
        if mount_dir.exists():
            fusermount_u(mount_dir)
        terminate_proc(client_proc)
        terminate_proc(server_proc)

if __name__ == "__main__":
    main()